const { Pool } = require('pg');
const dotenv = require('dotenv');

dotenv.config();

const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
});

pool.on('connect', () => {
    console.log('Connected to the PostgreSQL database.');
});

pool.on('error', (err) => {
    console.error('Unexpected error on idle client', err);
    process.exit(-1);
});

const initializeDatabase = async () => {
    const createTableQuery = `
        CREATE TABLE IF NOT EXISTS reports (
            id SERIAL PRIMARY KEY,
            nama TEXT NOT NULL,
            nomor_hp TEXT NOT NULL,
            email TEXT,
            lokasi_puskesmas TEXT,
            jenis_kelamin TEXT,
            deskripsi TEXT,
            unggah_gambar_luka TEXT,
            wound_score INTEGER,
            bukti_pendukung TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    `;

    try {
        await pool.query(createTableQuery);
        console.log('Table "reports" is ready.');
    } catch (err) {
        console.error('Error creating table:', err.message);
    }
};

initializeDatabase();

module.exports = pool;