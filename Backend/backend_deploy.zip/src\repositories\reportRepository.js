// Asumsi db adalah instance pg.Pool dari src/config/db.js
class ReportRepository {
    constructor(db) {
        this.db = db;
    }

    async create(reportData) {
        const query = `
            INSERT INTO reports 
            (nama, nomor_hp, email, lokasi_puskesmas, jenis_kelamin, deskripsi, unggah_gambar_luka, wound_score, bukti_pendukung) 
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
            RETURNING id
        `;

        const values = [
            reportData.name,
            reportData.phone,
            reportData.email,
            reportData.facility,
            reportData.gender,
            reportData.description,
            reportData.woundImageUrl,
            reportData.woundScore,
            reportData.imageUrl
        ];

        try {
            const result = await this.db.query(query, values);
            return {
                id: result.rows[0].id,
                ...reportData
            };
        } catch (err) {
            console.error("Repository Error creating report:", err);
            throw new Error("Gagal menyimpan laporan ke database.");
        }
    }

    async getById(id) {
        const query = `SELECT * FROM reports WHERE id = $1`;
        try {
            const result = await this.db.query(query, [id]);
            return result.rows[0];
        } catch (err) {
            throw err;
        }
    }
}

module.exports = ReportRepository;