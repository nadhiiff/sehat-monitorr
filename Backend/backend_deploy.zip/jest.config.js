module.exports = {
  testEnvironment: "node"
};
